`descriptor:åèä`
----------------

command åèä description

### Usage

* `descriptor:åèä [-o|--option_åèä] [--] <argument_åèä>`
* `descriptor:åèä -o|--option_name <argument_name>`
* `descriptor:åèä <argument_name>`

command åèä help

### Arguments

#### `argument_åèä`

* Is required: yes
* Is array: no
* Default: `NULL`

### Options

#### `--option_åèä|-o`

* Accept value: no
* Is value required: no
* Is multiple: no
* Default: `false`
