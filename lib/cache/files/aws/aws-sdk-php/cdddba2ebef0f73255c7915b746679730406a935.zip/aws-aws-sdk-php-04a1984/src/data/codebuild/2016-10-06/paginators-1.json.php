<?php
// This file was auto-generated from sdk-root/src/data/codebuild/2016-10-06/paginators-1.json
return [ 'pagination' => [],];
